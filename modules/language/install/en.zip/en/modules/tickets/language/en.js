Ext.namespace('GO.tickets');
GO.tickets.lang={};

GO.tickets.lang.ticket='Ticket';
GO.tickets.lang.tickets='Tickets';
GO.tickets.lang.type="Type";
GO.tickets.lang.types="Types";
GO.tickets.lang.status="Status";
GO.tickets.lang.statuses="Statuses";
GO.tickets.lang.ticketId="Ticket ID";

GO.tickets.lang.createTicket='Create ticket';
GO.tickets.lang.editTicket='Edit ticket';
GO.tickets.lang.reopen='Reopen';
GO.tickets.lang.reopenTooltip='Reopen ticket';
GO.tickets.lang.claim='Claim';
GO.tickets.lang.unclaim='Unclaim';
GO.tickets.lang.claimTooltip='Claim ticket';
GO.tickets.lang.unclaimTooltip='Unclaim ticket';
GO.tickets.lang.closeTicket='Close ticket';
GO.tickets.lang.ticketDetails='Ticket overview'
GO.tickets.lang.agent='Responsible';
GO.tickets.lang.contact='Contact';
GO.tickets.lang.unknownContact='<unknown>';
GO.tickets.lang.company='(company)';

GO.tickets.lang.message='Message';
GO.tickets.lang.messages='Messages';
GO.tickets.lang.editMessage='Edit message';
GO.tickets.lang.newMessage='New message';
GO.tickets.lang.statusChange='* Status changed to';
GO.tickets.lang.is_note='Note';
GO.tickets.lang.attachments='Attachments';
GO.tickets.lang.changeTicketStatus='Change ticket from status';
GO.tickets.lang.notified="Notified";
GO.tickets.lang.notifyContact="Notify contact";
GO.tickets.lang.notifyContactCheck="Notify contact defaults true";

GO.tickets.lang.template="Template";
GO.tickets.lang.templates="Templates";
GO.tickets.lang.emailTemplates="Email templates";
GO.tickets.lang.select_template="Use email template";

GO.tickets.lang.priority='Priority';
GO.tickets.lang.priority_low='Low';
GO.tickets.lang.priority_normal='Normal';
GO.tickets.lang.priority_high='High';

GO.tickets.lang.status_open='Open';
GO.tickets.lang.options='Options';
GO.tickets.lang.default_type='Default type';

GO.tickets.lang.default_template='Default response';
GO.tickets.lang.auto_reply='Ticket created by client';
GO.tickets.lang.ticket_created_for_client='Ticket created for client';

GO.tickets.lang.markAsRead='Mark as read';
GO.tickets.lang.markAsUnread='Mark as unread';

GO.tickets.lang.url='URL';
GO.tickets.lang.logo='Logo';

GO.tickets.lang.customer_message='Customer message on external page';
GO.tickets.lang.response_message='Ticket saved message on external page';
GO.tickets.lang.show_external='Show on external page';

GO.tickets.lang.show_from_others='Show tickets from others with this type to regular users';
GO.tickets.lang.showMineOnly='Only show my tickets';

GO.tickets.lang.addTicket = 'Add ticket';

GO.tickets.lang.attachFiles='Attach files';

GO.tickets.lang.rates='Rates';
GO.tickets.lang.rate='Rate';
GO.tickets.lang.amount='Amount';

GO.tickets.lang.rateHours='Rate / hours';
GO.tickets.lang.rateTotals='Rate totals';
GO.tickets.lang.bill='Bill';
GO.tickets.lang.toStatus='To status';
GO.tickets.lang.fromStatus='From status';

GO.tickets.lang.noRate='No rate';

GO.tickets.lang.notifyAgents='Notify agents by e-mail when new ticket is created by a visitor.';
GO.tickets.lang.notifyAdmin="Also send e-mail to users from the group 'Admins'";

GO.tickets.lang.youHaveNewTickets='You have {new} new ticket(s)';

GO.tickets.lang.messageTemplate='Message template';
GO.tickets.lang.sendMessage='Send message';
GO.tickets.lang.saveAsNote='Save as note';

GO.tickets.lang.ticketDeleted='Ticket no longer exists';

GO.tickets.lang.changeTicketsWithoutHoursToo='Change status of tickets without booked hours too';