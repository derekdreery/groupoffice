<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('tickets'));

$lang['tickets']['name']='Tickets';
$lang['tickets']['description']='Support ticket system';

$lang['tickets']['type']='Type';
$lang['tickets']['types']='Types';
$lang['link_type'][20]=$lang['tickets']['ticket']='Ticket';
$lang['tickets']['tickets']='Tickets';
$lang['tickets']['ticket_status']='Ticket status';
$lang['tickets']['ticket_statuses']='Ticket statuses';
$lang['tickets']['template']='Template';
$lang['tickets']['templates']='Templates';
$lang['tickets']['item']='Item';
$lang['tickets']['items']='Items';
$lang['tickets']['language']='Language';
$lang['tickets']['languages']='Languages';

$lang['tickets']['sent']= 'Sent';
$lang['tickets']['accepted']='Accepted';
$lang['tickets']['lost']='Lost';

$lang['tickets']['none']='None';
$lang['tickets']['default']='Default';
$lang['tickets']['nobody']='Nobody';

$lang['tickets']['no_email_template']='No e-mail template defined!';
$lang['tickets']['invald_email']='Invalid e-mail address';

$lang['tickets']['sendout']='Send comment to contact';
$lang['tickets']['issendout']='Contact has been notified';

$lang['tickets']['priority']='Priority';
$lang['tickets']['priority_level'][0]='Low';
$lang['tickets']['priority_level'][1]='Normal';
$lang['tickets']['priority_level'][2]='High';
$lang['tickets']['status_open']='Open';
$lang['tickets']['status_closed']='Closed';

$lang['tickets']['ticket_claim_error']='Ticket is claimed by ';
$lang['tickets']['ticket_action']['assigned_by']='Assigned by';
$lang['tickets']['ticket_action']['updated_by']='Updated by';
$lang['tickets']['ticket_action']['responded_by']='Responded by';

$lang['tickets']['subject']='Subject';
$lang['tickets']['question_issue']='Question / Issue';
$lang['tickets']['send']='Send';
$lang['tickets']['new_message']='New message';
$lang['tickets']['status_change']='Status changed to';
$lang['tickets']['attachments']='Attachments';
$lang['tickets']['mtime']='Modified at';
$lang['tickets']['ctime']='Created at';
$lang['tickets']['data']='Data';
$lang['tickets']['page']='Page';
$lang['tickets']['view_ticket']='View Ticket';
$lang['tickets']['new_ticket']='New Ticket';
$lang['tickets']['deleted_user']='Deleted user';

$lang['tickets']['template_default_name']='Default response';
$lang['tickets']['template_default_content']='Dear sir/madam

Thank you for your response,

{MESSAGE}

Please do not reply to this email. You must go to the following page to reply:
{LINK}

Best regards,
{NAME}.';

$lang['tickets']['template_created_by_client_name']='Default ticket created by client';
$lang['tickets']['template_created_by_client_content']='Dear sir/madam

We have received your question and a ticket has been created.
We will respond as soon as possible.

The message you sent to us was:
---------------------------------------------------------------------------
{MESSAGE}
---------------------------------------------------------------------------

Please do not reply to this email. You must go to the following page to reply:
{LINK}

Best regards,
{NAME}.';

$lang['tickets']['template_created_for_client_name']='Default ticket created for client';
$lang['tickets']['template_created_for_client_content']='Dear sir/madam

We have created a ticket for you.
We will respond as soon as possible.

The ticket is about:
---------------------------------------------------------------------------
{MESSAGE}
---------------------------------------------------------------------------

Please do not reply to this email. You must go to the following page to reply:
{LINK}

Best regards,
{NAME}.';

$lang['tickets']['example_type1']='IT';
$lang['tickets']['example_type2']='Sales';
$lang['tickets']['example_status1']='In progress';
$lang['tickets']['example_status2']='Not resolved';

$lang['tickets']['all_types']='All types';

$lang['tickets']['viewticketTitle']='Customers | Ticket summary';

$lang['tickets']['createticketTitle']='Customers | New ticket';

$lang['tickets']['customer_message']='This is our support system.

Please enter your contact information and describe your problem.';
$lang['tickets']['response_message']='Thank you for contacting us.
    
We have received your question and created a ticket for you. we will respond as soon as possible.

For future reference, your question has been assigned the following ticket number: {TICKET_NUMBER}.';

$lang['tickets']['period']='Period';

$lang['tickets']['invoiceCreated']='Invoice created';
$lang['tickets']['invoicesCreated']='%s invoice(s) created';

$lang['tickets']['number']='Number';
$lang['tickets']['newTicketSubject']='Ticket in type %s created by %s';


$lang['tickets']['bill_item_template']="{date} #{number} rate: {rate_name}\n{subject}";

$lang['tickets']['no_read_access']="Client doesn't has read permission to type";

$lang['tickets']['incomplete_delete']='You don\'t have permission to delete all selected tickets';