<?php
//Uncomment this line in new translations!
//require_once($GO_LANGUAGE->get_fallback_language_file('updateserver'));

$lang['updateserver']['name']='GO update';

$us_licenses='Licenses';
$us_package='Package';
$us_packages='Packages';
$us_package_name='Package name';
$us_name='Name';
$us_encode='Encode';
$us_src_path='Source path';
$us_version='Version';
$us_date='Date';

$us_host='Host';
$us_ip='IP';
$us_order_id='Order ID';
$us_license='License';

$us_add_package='Add package';
$us_add_product='Add product';

$us_new_license = 'New server license';
$us_new_license_text='Create a new server license for your server. The software will only run on this machine';
$us_include_packages='Include the following packages in this license';
$us_license_exists='You already have a server license for this hostname';
$us_license_already_has_package='The packages were already in the server license. You should create a new license for these packages.';
$us_download='Download';

$us_new_products='Thank you for purchasing new products. You can add these products to an existing server license or you can create a new server license for a different machine.';

$us_required_products='Required products';
$us_upgrade_products='Upgrade products';
$us_is_upgrade_to='This package is an upgrade to';
$us_expires='Expires';
$us_expired='Expired';

$us_upgrade_price='Upgrade price';
$us_upgrade_vat='Upgrade VAT';
$us_upgrade='Upgrade';

$us_upgrade_available='Upgrades available!';

$us_any_host='Any host';
?>
