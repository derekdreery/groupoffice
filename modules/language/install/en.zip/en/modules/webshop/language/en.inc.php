<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('webshop'));

$lang_modules['webshop']= 'Webshop';

$lang['webshop']['no_webshop']='No webshop';

$lang['webshop']['select_payment']= 'Select the payment method';
$lang['webshop']['pay']= 'Pay';

$lang['webshop']['thanks']= 'Thank you for your order';

$lang['webshop']['cart']= 'Shopping cart';
$lang['webshop']['catalog_text']= 'Click at the buy button to purchase a product. '.
'You will be able to pay with Visa/Mastercard or by bank transfer.
After payment you will be able to print out an invoice.';

$lang['webshop']['buy']= 'Buy';
$lang['webshop']['checkout']= 'Checkout';
$lang['webshop']['customer_info']= 'Please check your data';
$lang['webshop']['confirm_order']= 'Order confirmation';
$lang['webshop']['confirm_order_text']= 'Please verify that all the information below is correct and'.
 ' click at payment method to confirm your order and continue to the payment.';
 
$lang['webshop']['products']= 'Selected products';
$lang['webshop']['continue_shopping']= 'Continue shopping';

$lang['webshop']['shopping_cart_text']= 'These products are in your shopping cart. You can change the amounts here and save them (Choose 0 to delete a product).';
$lang['webshop']['book']= 'Book';

$lang['webshop']['settings']= 'Settings';

$lang['webshop']['no_orders']= 'No orders found';


$lang['webshop']['add_to_cart']= 'Order';
$lang['webshop']['price']='Price';
$lang['webshop']['empty_shopping_cart']= 'Your shopping cart is empty';

$lang['webshop']['in_stock']= 'In stock';
$lang['webshop']['out_of_stock']= 'Out of stock';


$lang['webshop']['payments']='Payment methods';
$lang['webshop']['default_status']='Default order status';

$lang['webshop']['site']= 'Website';

$lang['webshop']['bonus_points']= 'You\'ll recieve %s bonus points with this product';
$lang['webshop']['userfield']= 'User data field';

$lang['webshop']['from']= 'From';
$lang['webshop']['for']= 'for';

$lang['webshop']['or']= 'or';
$lang['webshop']['or_bonus_points']= 'bonus points';

$lang['webshop']['status_messages']='Status messages';

$lang['webshop']['status_message_instructions']= 'This message will be send to the customer when the shop automatically changes the status of an order.';

$lang['webshop']['success_continue']= 'A confirmation e-mail has been sent to your e-mail. Click at the button below to continue';

$lang['webshop']['bonus_point_discount']= 'Discount with % bonus points';

$lang['webshop']['shipping_costs']= 'Shipping costs';

$lang['webshop']['product_in_cart']= 'The product has been added to your shopping cart. You can add more products or checkout';

$lang['webshop']['info']='Information';


$lang['webshop']['use_bonus_points']= 'You can use bonuspoints';
$lang['webshop']['use_bonus_points_text']= 'You can use a maximum of %s bonuspoints with this order. This will give you up to %s discount. Please enter the number of bonuspoints you wish to use.';

$lang['webshop']['to_much_bonus_points']= 'You entered to much bonus points';

$lang['webshop']['purchase_price']='Purchase price';
$lang['webshop']['payment_method']='Payment method';

$lang['webshop']['click_here_to_pay']='Click here to pay online';

$lang['webshop']['payment_template']='Payment page template';
$lang['webshop']['order_book']='Order book';
$lang['webshop']['invoice_book']='Invoice book';
$lang['webshop']['bonus_point_value']='Bonus point value';
$lang['webshop']['shipping_costs_admin']='Shipping costs';
$lang['webshop']['free_shipping_treshold']='Free shipping treshold';
$lang['webshop']['currency']='Currency';
$lang['webshop']['bonus_point_succes_status']='Bonus point succes status';


$lang['webshop']['payment']='Payment';
$lang['webshop']['payments']='Payments';
$lang['webshop']['image']='Image';
$lang['webshop']['order_success_status']='Order success status';
$lang['webshop']['pending_status_id']='Pending status';
$lang['webshop']['failed_status_id']='Failed status';
$lang['webshop']['options']='Options';
$lang['webshop']['language']='Language';

$lang['webshop']['invoice_success_status']= 'Invoice success status';

$lang['webshop']['no_webshops']= 'No webshops created';
$lang['webshop']['vat_no']='VAT no.';
$lang['webshop']['bonus_points_admin']='Bonus points';
$lang['webshop']['webshop']='Webshop';

$lang['webshop']['full_go_url']='Full URL to Group-Office in shop';

$lang['webshop']['order_pending_status']='Pending order status';
$lang['webshop']['bonus_product']='Bonus product';
$lang['webshop']['bonus_products']='Bonus products';
$lang['webshop']['webshop_id']='Webshop';
$lang['webshop']['product_id']='Product';
$lang['webshop']['amount']='Amount';
$lang['webshop']['free']='Free!';

$lang['webshop']['order_failed_status']= 'Order failed status';
$lang['webshop']['verifying_status_id']='Verifying payment';

$lang['webshop']['stock']='Stock';
$lang['webshop']['status']='Status';
$lang['webshop']['total']='Total';
$lang['webshop']['no_status']='None';
$lang['webshop']['unknown']='Unknown';
$lang['webshop']['view']='View';
$lang['webshop']['bonus_points']='Bonus points';
$lang['webshop']['product_category']='Product category';
$lang['webshop']['shopping_cart']='Shopping cart';
$lang['webshop']['vat']='VAT';

$lang['webshop']['insert_product_category']='Insert product category';
$lang['webshop']['delete']='Delete';
$lang['webshop']['invalidOrderID']='Error: invalid order ID. Please contact the webmaster';
$lang['webshop']['noContentTag']='No content tag in template';

$lang['webshop']['badlogin']='Wrong username or password';

$lang['webshop']['must_agree']='You must agree to the license terms and conditions';