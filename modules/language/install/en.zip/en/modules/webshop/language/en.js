Ext.namespace('GO.webshop');

GO.webshop.lang={};
GO.webshop.lang.webshop='Webshop';

/* table: ws_webshops */
GO.webshop.lang.webshop="Webshop";
GO.webshop.lang.webshops="Webshops";
GO.webshop.lang.currency="Currency";
GO.webshop.lang.languageId="Language";
GO.webshop.lang.orderBookId="Order book";
GO.webshop.lang.invoiceBookId="Invoice book";
GO.webshop.lang.bonusPointValue="Bonuspoint value";
GO.webshop.lang.orderSuccessStatusId="Order success status";
GO.webshop.lang.invoiceSuccessStatusId="Invoice success status";
GO.webshop.lang.shippingCosts="Shipping costs";
GO.webshop.lang.freeShippingTreshold="Free shipping treshold";
GO.webshop.lang.fullGoUrl="Full go url";
GO.webshop.lang.orderFailedStatusId="Order failed status";
GO.webshop.lang.orderPendingStatusId="Order pending status";

/* table: ws_payments */
GO.webshop.lang.payment="Payment";
GO.webshop.lang.payments="Payments";
GO.webshop.lang.webshopId="Webshop";
GO.webshop.lang.image="Image";
GO.webshop.lang.pendingStatusId="Pending status";
GO.webshop.lang.failedStatusId="Failed status";
GO.webshop.lang.options="Options";

GO.webshop.lang.site='Site';

GO.webshop.lang.screenTemplate='Screen template';
