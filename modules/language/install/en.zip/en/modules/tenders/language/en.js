Ext.namespace('GO.tenders');
GO.tenders.lang={};
GO.tenders.lang.tenders='tenders';

/* table: te_tenders */
GO.tenders.lang.tender="Tender";
GO.tenders.lang.tenders="Tenders";
GO.tenders.lang.refdtd="Refdtd";
GO.tenders.lang.origid="Origid";
GO.tenders.lang.lg="Lg";
GO.tenders.lang.lgorig="Lgorig";
GO.tenders.lang.hd="Hd";
GO.tenders.lang.colloj="Colloj";
GO.tenders.lang.nooj="Nooj";

GO.tenders.lang.datepub="Published";

GO.tenders.lang.lgoj="Lgoj";
GO.tenders.lang.sectorCode="Sector code";
GO.tenders.lang.sectorText="Sector text";
GO.tenders.lang.natnoticeCode="Natnotice code";
GO.tenders.lang.natnoticeText="Natnotice text";
GO.tenders.lang.marketCode="Market code";
GO.tenders.lang.marketText="Market text";
GO.tenders.lang.procCode="Proc code";
GO.tenders.lang.procText="Proc text";
GO.tenders.lang.marketorgCode="Marketorg code";
GO.tenders.lang.marketorgText="Marketorg text";
GO.tenders.lang.typebidCode="Typebid code";
GO.tenders.lang.typebidText="Typebid text";
GO.tenders.lang.awardcritCode="Awardcrit code";
GO.tenders.lang.awardcritText="Awardcrit text";
GO.tenders.lang.datedisp="Datedisp";
GO.tenders.lang.daterec="Daterec";

GO.tenders.lang.deadlinereq="Deadline";

GO.tenders.lang.deadlinerec="Deadline";

GO.tenders.lang.refnotice="Refnotice";

GO.tenders.lang.isocountry="Country";

GO.tenders.lang.nodocojs="Nodocojs";

GO.tenders.lang.tidoc="Title";

GO.tenders.lang.contents="Contents";

GO.tenders.lang.stidoc="Subtitles";

GO.tenders.lang.objnot="Objnot";

GO.tenders.lang.nuts='Regions';
GO.tenders.lang.cpv='CPV codes';

/* table: te_tenders */
GO.tenders.lang.search="Search";
GO.tenders.lang.searches="Searches";

GO.tenders.lang.nutsEmptyText='NUTS - Code(s)';
GO.tenders.lang.cpvEmptyText='CPV - Code(s)';

GO.tenders.lang.noSavedSearches = 'You don\'t have saved searches';

GO.tenders.lang.lastDay='Last 24 hours';

GO.tenders.lang.awards='Awards';

GO.tenders.lang.saveSearchAs='Save search as';

GO.tenders.lang.notifyTenders='Enable e-mail notification of matching tenders';
GO.tenders.lang.notifyAwards='Enable e-mail notification of matching awards';
