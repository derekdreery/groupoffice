<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('tenders'));
$lang['tenders']['name']='tenders';
$lang['tenders']['description']='Put a description here';
$lang['tenders']['tender']='Tender';
$lang['tenders']['tenders']='Tenders';
$lang['tenders']['search']='Search';
$lang['tenders']['searches']='Searches';


$lang['tenders']['email_subject']='Uw tenders en gunningen';
$lang['tenders']['email_header']='<h1>E-mail notificatie van Tenders2GO</h1>
<p>
Hieronder staat een overzicht van gevonden tenders en/of gunningen die voldoen aan uw zoekprofiel en sinds gisteren zijn toegevoegd.</p><hr />';


$lang['tenders']['email_summary']='Overzicht van de gevonden berichten';

$lang['tenders']['email_award']='Geplaatste opdracht';
$lang['tenders']['email_tender']='Aankondiging van een opdracht';

$lang['tenders']['email_url']='http://www.tenders2go.com/NL/Tenders+en+gunningen/Uw+tenders&tender_id={tender_id}';

$lang['tenders']['email_footer']='<hr /><p>We halen alles uit de kast als Tenders2GO om bedrijven als dat
van u tenders te laten winnen en zo de orderportefeuille uit te breiden.<br />
Telefoon: 0800-3698741 (gratis). E-mail: info@tenders2go.com</p>';
