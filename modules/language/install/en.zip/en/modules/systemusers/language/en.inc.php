<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('users'));
$lang['systemusers']['name']='System users';
$lang['systemusers']['description']='Creates system users for every Group-Office user';
$lang['systemusers']['vacation_not_executable_error']='Vacation is not installed or not executable.';