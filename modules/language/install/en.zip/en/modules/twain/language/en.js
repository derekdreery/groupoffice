Ext.namespace('GO.twain');

GO.twain.lang={};
GO.twain.lang.scan='Scan';