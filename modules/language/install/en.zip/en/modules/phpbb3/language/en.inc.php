<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('email'));
$lang['phpbb3']['name'] = 'phpBB3';
$lang['phpbb3']['description'] = 'Bridge between phpBB3 and Group-Office.';