/**
 * Don't copy the next lines into a translation
 */
 
Ext.namespace('GO.phpbb3');

GO.phpbb3.lang={};
/**
 * Copy everything below for translations
 */

GO.phpbb3.lang.forum='Forum';