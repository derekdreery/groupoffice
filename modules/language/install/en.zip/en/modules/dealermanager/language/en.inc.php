<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('dealermanager'));
$lang['dealermanager']['name']='dealermanager';
$lang['dealermanager']['description']='Put a description here';
$lang['dealermanager']['report']='Report';
$lang['dealermanager']['reports']='Reports';


