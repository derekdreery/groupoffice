Ext.namespace('GO.dealermanager');
GO.dealermanager.lang={};
GO.dealermanager.lang.dealermanager='Dealer manager';

/* table: dm_reports */
GO.dealermanager.lang.report="Report";
GO.dealermanager.lang.reports="Reports";
GO.dealermanager.lang.countUsers="Count users";
GO.dealermanager.lang.installTime="Install time";
GO.dealermanager.lang.lastlogin="Lastlogin";
GO.dealermanager.lang.totalLogins="Total logins";
GO.dealermanager.lang.databaseUsage="Database usage";
GO.dealermanager.lang.fileStorageUsage="File storage usage";
GO.dealermanager.lang.mailboxUsage="Mailbox usage";
GO.dealermanager.lang.features="Features";
GO.dealermanager.lang.mailDomains="Mail domains";
GO.dealermanager.lang.billPeriod="Bill period";
GO.dealermanager.lang.nextBillTime="Next bill time";
GO.dealermanager.lang.diskspaceDiscount="Diskspace discount";
GO.dealermanager.lang.serviceDiscount="Service discount";
GO.dealermanager.lang.comment="Comment";
GO.dealermanager.lang.vat='VAT';
GO.dealermanager.lang.status='Status';