
GO.moduleManager.on('languageLoaded',function(){

	GO.lang.extra='Tools';
	
	GO.lang.strMtime = 'Updated on';
	GO.lang.strCtime = 'Date created';

	if(GO.projects){
		GO.projects.lang.project = 'Cabinet';
		GO.projects.lang.projects = 'Cabinets';
		GO.projects.lang.noProjects = 'No cases to display';
		GO.projects.lang.projectInfo = 'Cabinet information';
		GO.projects.lang.activeProjects = 'Active cases';
		GO.projects.lang.projectAdministration = 'Case administration';
		GO.projects.lang.feeAdministration = 'Fee administration';
		GO.projects.lang.archiveProject = 'Complete this case. Completed cases are removed from the dropdown when you book hours.';
		GO.projects.lang.maxProjectsReached='The maximum number of cases has been reached. Contact your hosting provider to activate unlimited usage of the cases module.';

		//GO.projects.lang.subprojects='Cabinet items';
		GO.projects.lang.subproject='Sub item';

		GO.projects.lang.projectEnded='This case should have been completed already!';
		GO.projects.lang.tree='Cabinet Tree';
		GO.projects.lang.showMineOnly='Show my cases only';

		GO.projects.lang.reportDetails = 'Analysis details';
		GO.projects.lang.reports = 'Analysis';
		GO.projects.lang.reportTemplate="Analysis template";
		GO.projects.lang.reportTemplates="Analysis templates";
		GO.projects.lang.customReport="Analysis";
		GO.projects.lang.customReports="Analysis";

		GO.projects.lang.startTime='Start date';
		GO.projects.lang.dueAt='Completion date';
		GO.projects.lang.batchReports='Batch analysis';
	}

	if(GO.email){
		GO.email.defaultProgramInstructions ='<p>If you are using Windows you can download and run <a class="normal-link" href="{url}">this register file</a> to set Legal-Horizons as your default e-mail program.</p>';
	}

	if(GO.calendar){
		GO.calendar.lang.appointment = 'Event';
		GO.calendar.lang.appointments = 'Events';
	}

	if(GO.files){
		GO.files.lang.files='Documents';
	}
});