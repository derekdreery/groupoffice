<?php
$lang['projects']['name']='Cabinet';
$lang['projects']['description']='Cabinet module';

$lang['projects']['projects']='Cabinets';

$lang['link_type'][5]=$lang['projects']['project']='Cabinet';

$lang['link_type'][1]='Event';
?>
