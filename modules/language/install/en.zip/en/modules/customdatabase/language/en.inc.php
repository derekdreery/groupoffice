<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('customdatabase'));
$lang['customdatabase']['name']='customdatabase';
$lang['customdatabase']['description']='Put a description here';
$lang['customdatabase']['type']='Type';
$lang['customdatabase']['types']='Types';
$lang['customdatabase']['item']='Item';
$lang['customdatabase']['items']='Items';
