Ext.namespace('GO.customdatabase');
GO.customdatabase.lang={};
GO.customdatabase.lang.customdatabase='customdatabase';

/* table: cd_types */
GO.customdatabase.lang.type="Type";
GO.customdatabase.lang.types="Types";
GO.customdatabase.lang.categories="Categories";

/* table: cd_items */
GO.customdatabase.lang.item="Item";
GO.customdatabase.lang.items="Items";
GO.customdatabase.lang.typeId="Type id";
