<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('serverclient'));

$lang['serverclient']['name']='Serverclient';
$lang['serverclient']['description']='Automatically create mailboxes on a Group-Office installation that manages the e-mail server with the postfixadmin module';
$lang['serverclient']['connect_error']='Could not connect to %s';