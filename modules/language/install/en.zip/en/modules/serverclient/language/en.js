/**
 * Don't copy the next lines into a translation
 */

Ext.namespace('GO.serverclient');

GO.serverclient.lang={};
/**
 * Copy everything below for translations
 */

GO.serverclient.lang.mailboxes='Mailboxes';
GO.serverclient.lang.createMailbox='Create a mailbox for domain';