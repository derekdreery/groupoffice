<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('gnupg'));
$lang['gnupg']['name']='GnuPG';
$lang['gnupg']['description']='Send PGP encrypted e-mail messages';

$lang['gnupg']['importSuccessful']='Key imported successfully';