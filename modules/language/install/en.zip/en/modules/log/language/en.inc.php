<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('log'));
$lang['log']['name']='Log';
$lang['log']['description']='Logs all add, update and delete actions';

