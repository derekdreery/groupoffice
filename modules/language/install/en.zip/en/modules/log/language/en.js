Ext.namespace('GO.log');
GO.log.lang={};
GO.log.lang.log='Log';

GO.log.lang.time="Time";

