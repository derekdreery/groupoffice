/**
 * Don't copy the next lines into a translation
 */
 Ext.namespace('GO.comments');
 GO.comments.lang={};
/**
 * Copy everything below for translations
 */

GO.comments.lang.comment="Comment";
GO.comments.lang.comments="Comments";
GO.comments.lang.recentComments='Recent comments';
GO.comments.lang.browseComments = 'Browse comments';