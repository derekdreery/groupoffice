<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('comments'));
$lang['comments']['name']='Comments';
$lang['comments']['description']='Adds comments functionality to other modules';
$lang['comments']['comment']='Comment';
$lang['comments']['comments']='Comments';
