<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('notes'));

$lang['notes']['note']='Note';
$lang['notes']['name']='Notes';
$lang['notes']['description']='A module to make to notes';

$lang['notes']['category']='Category';
$lang['notes']['categories']='Categories';
$lang['link_type'][4]=$lang['notes']['note']='Note';
$lang['notes']['notes']='Notes';

$lang['notes']['general'] = 'General';
$lang['notes']['incomplete_delete']='You don\'t have permission to delete all selected notes';