<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('ab2users'));
$lang['ab2users']['name']='Addressbook2Users';
$lang['cms']['description']='Adds a button to quickly create a user from a contact or company';
