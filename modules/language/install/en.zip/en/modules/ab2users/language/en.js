Ext.namespace('GO.ab2users');

GO.ab2users.lang={};
GO.ab2users.lang.createUser='Create user';
GO.ab2users.lang.companyUserFirstName='Company';