<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('tools'));

$lang['tools']['name']='Tools';
$lang['tools']['description']='A module to perform administrative tasks.';

$lang['tools']['dbcheck']='Database check';
$lang['tools']['rm_duplicates']='Remove duplicate contacts and events';

$lang['tools']['backupdb']='Backup database';
$lang['tools']['index_files']='Index all files';

$lang['tools']['buildsearchcache']='Create search index';
$lang['tools']['checkmodules']='Check modules';
$lang['tools']['resetState']='Reset state of windows, grids etc.';
?>