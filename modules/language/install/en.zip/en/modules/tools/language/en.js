/**
 * Don't copy the next lines into a translation
 */
Ext.namespace('GO.tools');

GO.tools.lang = {};
/**
 * Copy everything below for translations
 */


GO.tools.lang.tools='Admin tools';
GO.tools.lang.description='Click on one of the scripts below to execute it.';

GO.tools.lang.scripts='Scripts';
GO.tools.lang.scriptOutput='Script output';