<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('currencies'));
$lang['currencies']['name']='currencies';
$lang['currencies']['description']='Put a description here';
$lang['currencies']['currency']='Currency';
$lang['currencies']['currencies']='Currencies';
