Ext.namespace('GO.currencies');
GO.currencies.lang={};
GO.currencies.lang.currencies='currencies';

/* table: cu_currencies */
GO.currencies.lang.currency="Currency";
GO.currencies.lang.currencies="Currencies";
GO.currencies.lang.code="Code";
GO.currencies.lang.symbol="Symbol";
GO.currencies.lang.value="Value";
