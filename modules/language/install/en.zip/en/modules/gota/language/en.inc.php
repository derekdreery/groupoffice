<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('gota'));
$lang['gota']['name'] = 'GOTA';
$lang['gota']['description'] = 'Group-Office Transfer Agent. Can edit online files locally and transfers modifcations back to Group-Office';

