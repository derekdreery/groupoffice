Ext.namespace('GO.licenses');
GO.licenses.lang={};
GO.licenses.lang.licenses='Licenses';

/* table: us_licenses */
GO.licenses.lang.license="License";
GO.licenses.lang.licenses="Licenses";
GO.licenses.lang.host="Host";
GO.licenses.lang.ip="Ip";
GO.licenses.lang.linkId="Link id";
GO.licenses.lang.expires="Expires";
GO.licenses.lang.upgrades="Upgrades";
GO.licenses.lang.notified="Notified";

/* table: us_packages */
GO.licenses.lang['package']="Package";
GO.licenses.lang.packages="Packages";
GO.licenses.lang.packageName="Package name";
GO.licenses.lang.version="Version";
GO.licenses.lang.date="Date";
GO.licenses.lang.upgradePrice="Upgrade price";
GO.licenses.lang.upgradeVat="Upgrade vat";
GO.licenses.lang.file="File";

GO.licenses.lang.products='Products';
GO.licenses.lang.upgradePackages='Upgrade packages';
GO.licenses.lang.passphrase='Passphrase';