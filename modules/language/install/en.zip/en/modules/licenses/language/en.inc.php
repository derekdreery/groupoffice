<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('licenses'));
$lang['licenses']['name']='licenses';
$lang['licenses']['description']='Put a description here';
$lang['licenses']['license']='License';
$lang['licenses']['licenses']='Licenses';
$lang['licenses']['package']='Package';
$lang['licenses']['packages']='Packages';
