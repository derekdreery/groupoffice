Ext.namespace('GO.reminders');
GO.reminders.lang={};
GO.reminders.lang.reminders='Popup reminders';

/* table: go_reminders */
GO.reminders.lang.reminder="Popup reminder";
GO.reminders.lang.time="Time";
GO.reminders.lang.snoozeTime="Snooze time";
GO.reminders.lang.text='Text';
GO.reminders.lang.addUsers='Add users';
GO.reminders.lang.addUserGroups='Add user groups';