<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('reminders'));
$lang['reminders']['name']='Popup reminders';
$lang['reminders']['description']='A module to schedule popup reminders for users or user groups.';

