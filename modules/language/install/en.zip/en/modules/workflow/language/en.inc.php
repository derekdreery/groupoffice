<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('workflow'));
$lang['workflow']['name']='workflow';
$lang['workflow']['description']='Put a description here';
$lang['workflow']['process']='Process';
$lang['workflow']['processes']='Processes';
$lang['workflow']['step']='Step';
$lang['workflow']['steps']='Steps';
$lang['workflow']['step_history_item']='Step history item';
$lang['workflow']['step_history']='Step history';


$lang['workflow']['approval_required_subject']='Approval request for %s';

$lang['workflow']['approval_required_body']='Your approval is required for step %s in the workflow process of file %s.<br />%s<a href="%s">Click here to open the file properties</a>';
$lang['workflow']['approval_required_body_last_comment']='At %s, %s %s step %s.';


$lang['workflow']['goAlreadyStarted']='Group-Office was already started in another window. Close this window and lookup the Group-Office window to view the file properties you requested.';

$lang['workflow']['late'] = 'late';