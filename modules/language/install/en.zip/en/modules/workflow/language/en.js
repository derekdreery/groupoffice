Ext.namespace('GO.workflow');
GO.workflow.lang={};
GO.workflow.lang.workflow='Workflow';

/* table: wf_processes */
GO.workflow.lang.process="Process";
GO.workflow.lang.processes="Processes";

/* table: wf_steps */
GO.workflow.lang.step="Step";
GO.workflow.lang.steps="Steps";
GO.workflow.lang.aclId="Acl id";
GO.workflow.lang.sortorder="Sortorder";
GO.workflow.lang.dueIn="Due in (hours)";
GO.workflow.lang.emailAlert="Email alert";
GO.workflow.lang.popupAlert="Popup alert";

/* table: wf_step_history */
GO.workflow.lang.stepHistoryItem="Step history item";
GO.workflow.lang.stepHistory="Workflow history";
GO.workflow.lang.fileId="File id";
GO.workflow.lang.stepId="Step id";
GO.workflow.lang.comment="Comment";

GO.workflow.lang.approvers='Approvers';

GO.workflow.lang.approve='Approve';
GO.workflow.lang.reject='Reject';

GO.workflow.lang.statuses={};
GO.workflow.lang.statuses[1]="Approved";
GO.workflow.lang.statuses[2]="Rejected";

GO.workflow.lang.status='Status';

GO.workflow.lang.approvalRequiredBy='Approval required by';
GO.workflow.lang.allMustApprove='Approval is requited from all approvers';

GO.workflow.lang.timeRunning='Time running';
GO.workflow.lang.progress='Progress';

GO.workflow.lang.showCompleted='Show completed';
GO.workflow.lang.showRequiredOnly='Show required approvals only';
GO.workflow.lang.filter='Filter';

GO.workflow.lang.shiftDueTime='Shift due time';

GO.workflow.lang.createNewWorkflowProcess='Create new workflow process';
GO.workflow.lang.noProcess='No workflow process';