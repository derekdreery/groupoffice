Ext.namespace("GO.customcss");

GO.customcss.lang={};
GO.customcss.lang.customcss='Custom CSS';

GO.customcss.lang.selectFile='Select file';
