<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('servermanager'));
$lang['servermanager']['name']='servermanager';
$lang['servermanager']['description']='Put a description here';
$lang['servermanager']['installation']='Installation';
$lang['servermanager']['installations']='Installations';
$lang['servermanager']['invalidEmail']='Please enter a valid e-mail address';
$lang['servermanager']['noHost']='Please enter a hostname';
$lang['servermanager']['invalidHost']='The hostname may only contain the charachters a to z';
$lang['servermanager']['duplicateHost']='Sorry, the hostname already exists';

$lang['servermanager']['new_trial_subject']='Complete your Group-Office trial installation';