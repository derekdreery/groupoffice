<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('postfixadmin'));
$lang['postfixadmin']['name']='Postfix admin';
$lang['postfixadmin']['description']='A module to manage virtual postfix users in the Group-Office database';
$lang['postfixadmin']['alias']='Alias';
$lang['postfixadmin']['aliases']='Aliases';
$lang['postfixadmin']['domain']='Domain';
$lang['postfixadmin']['domains']='Domains';
$lang['postfixadmin']['fetchmail_config']='Fetchmail config';
$lang['postfixadmin']['fetchmail_configs']='Fetchmail configs';
$lang['postfixadmin']['mailbox']='Mailbox';
$lang['postfixadmin']['mailboxes']='Mailboxes';
$lang['postfixadmin']['vacation_config']='Vacation config';
$lang['postfixadmin']['vacation_configs']='Vacation configs';
