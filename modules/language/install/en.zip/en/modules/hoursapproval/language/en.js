Ext.namespace("GO.hoursapproval");
Ext.namespace('GO.projects');

GO.hoursapproval.lang={};

GO.hoursapproval.lang.hoursapproval='Approve timeregistration';

GO.hoursapproval.lang.enterDisapproveReason='Please enter the reason for disapproval';
GO.hoursapproval.lang.disapprove='Disapprove';
GO.hoursapproval.lang.approve='Approve';