<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('hoursapproval'));
$lang['hoursapproval']['name'] = 'Approve timeregistration';
$lang['hoursapproval']['description'] = 'Project managers can review timeregistation and approve it.';

$lang['hoursapproval']['disapproveSubject']='Timeregistration disapproved';
$lang['hoursapproval']['disapproveBody']='%s disapproved your timeregistration of week %s. Please read the comment and correct the time registration at:

%s

Comment:

';
?>
