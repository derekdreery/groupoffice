<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('sync'));

$lang['sync']['name']='Synchronization';
$lang['sync']['description']='Synchronization server for mobile devices using ActiveSync and SyncML';

$lang['sync']['info']='<h1>Group-Office SyncML Server</h1><p>This is the Group-Office SyncML server. Use a SyncML compliant '.
 'device or software package and connect it to this URL to synchronize with '.
 'Group-Office.</p><p>For more information about setting up the device visit <a href="http://www.group-office.com/wiki/Synchronization">http://www.group-office.com/wiki/Synchronization</a></p>';

?>