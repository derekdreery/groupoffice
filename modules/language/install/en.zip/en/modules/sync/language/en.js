/**
 * Don't copy the next lines into a translation
 */

Ext.namespace('GO.sync');

GO.sync.lang={};
/**
 * Copy everything below for translations
 */

GO.sync.lang.sync='Synchronization';
GO.sync.lang.max_age_text='Set a maximum age of events and tasks. If an event or task is older then that number of days it will not be synchronized. You can also choose to delete older events from the client. This will keep your mobile device clean and fast.';
GO.sync.lang.max_age='Maximum days old';
GO.sync.lang.delete_old_events='Delete older events and tasks at the client (they will be kept in Group-Office)';
GO.sync.lang.addressbooks='Addressbooks';
GO.sync.lang.addressbook='Addressbook';
GO.sync.lang.selectType='Synchronize';
GO.sync.lang.defaultType='Default';
GO.sync.lang.noDefaultAddressbook='Please select a default addressbook for synchronisation.';

GO.sync.lang.devices = 'Devices';
GO.sync.lang.device = 'Device';

GO.sync.lang.manufacturer='Manufacturer';
GO.sync.lang.model='Model';

GO.sync.lang.noDefaultTasklist='Please select a default tasklist for synchronisation.';