<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('filesearch'));
$lang['filesearch']['name']='File search';
$lang['filesearch']['description']='Advanced search engine for files';

$lang['link_type'][16]=$lang['filesearch']['docbundle']='Document bundle';
$lang['filesearch']['docbundles']='Document bundles';
