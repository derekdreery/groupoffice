Ext.namespace('GO.filesearch');

GO.filesearch.lang={};

GO.filesearch.lang.author='Author';
GO.filesearch.lang.lastModifiedBy='Last modified by';
GO.filesearch.lang.contentPreview='Content preview';
GO.filesearch.lang.noPreview='No preview available';


/* table: fs_docbundles */
GO.filesearch.lang.docbundle="Document bundle";
GO.filesearch.lang.docbundles="Document bundles";
GO.filesearch.lang.selectDocbundle = 'Select document bundle';
GO.filesearch.lang.fulltextPDF ='Full text PDF';

