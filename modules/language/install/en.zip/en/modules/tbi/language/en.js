GO.moduleManager.on('languageLoaded',function(){

	if(GO.reminders){
		GO.reminders.lang.reminders = 'Monteurs nabellen / Popup';
	}
});