/**
 * Don't copy the next lines into a translation
 */
if(!GO.customfields)
{
	Ext.namespace("GO.customfields");
	GO.customfields.types={};
	GO.customfields.columns={};
}

GO.customfields.lang={};
/**
 * Copy everything below for translations
 */


GO.customfields.lang.customfields = 'Custom fields';
GO.customfields.lang.category = 'Category';
GO.customfields.lang.categories = 'Custom field categories';
GO.customfields.lang.manageCategories = 'Manage categories';
GO.customfields.lang.numberField = '<br />You can use any number field. Wrap field names in {} and put a space between every word (eg. {Number1} + {Number2} and not Number1+Number2):<br /><br />';
GO.customfields.lang.selectOptions = 'Select options';
GO.customfields.lang.noOptions = 'There are no options defined yet';
GO.customfields.lang.enterText = 'Please enter the text of the option:';
GO.customfields.lang.functionProperties = 'Function properties';
GO.customfields.lang.restart = 'Changes you make here will take affect after you restart Group-Office.';
GO.customfields.lang.noFields = 'No custom fields to display';
GO.customfields.lang.createCategoryFirst='You must create a category first';
GO.customfields.lang.required='Required field';
GO.customfields.lang.validationRegexp='Validation regexp.';
GO.customfields.lang.helpText='Help text';

GO.customfields.lang.importText='Upload a CSV file with a single column for the value or just with the value on each line.';
GO.customfields.lang.multiselect='Multiselect';