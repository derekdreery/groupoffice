<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('customfields'));
$lang['customfields']['name']='Custom fields';
$lang['customfields']['description']='Adds extra fields to the addressbook and projects module.';
