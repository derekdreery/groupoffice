/**
 * Don't copy the next lines into a translation
 */

Ext.namespace('GO.projects');

GO.projects.lang={};
/**
 * Copy everything below for translations
 */

GO.projects.lang.userFees='Default fees';
GO.projects.lang.project = 'Project';
GO.projects.lang.projects = 'Projects';
GO.projects.lang.noProjects = 'No Projects to display';
GO.projects.lang.projectInfo = 'Project information';
GO.projects.lang.activeProjects = 'Active projects';
GO.projects.lang.units = 'Units';
GO.projects.lang.responsible = 'Responsible';
GO.projects.lang.fee = 'Fee';
GO.projects.lang.valueMinutes = 'Value per minutes';
GO.projects.lang.internalFee = 'Internal fee';
GO.projects.lang.externalFee = 'External fee';
GO.projects.lang.unitValue = 'Unit value';
GO.projects.lang.noFees = 'There are no fees defined yet';
GO.projects.lang.noHours = 'No hours to display';
GO.projects.lang.timeTracking = 'Time tracking';
GO.projects.lang.projectAdministration = 'Project administration';
GO.projects.lang.specialFees = 'Special fees';
GO.projects.lang.milestone = 'Milestone';
GO.projects.lang.milestones = 'Milestones';
GO.projects.lang.noMilestones = 'There are no milestones defined yet for this project';
GO.projects.lang.due = 'Due';
GO.projects.lang.completionTime = 'Completion time';
GO.projects.lang.archiveProject = 'Complete this project. Completed projects are removed from the dropdown when you book hours.';
GO.projects.lang.bookPermission = 'Book permission';
GO.projects.lang.informationAbout = 'Information about';
GO.projects.lang.assignedTo = 'Assigned to';
GO.projects.lang.noData = 'There\'s no data to show';
GO.projects.lang.reportDetails = 'Report details';
GO.projects.lang.datefieldsInfo = 'If you leave the date fields empty you will get all time statistics. You can doubleclick on rows to view or export the details in a list.';
GO.projects.lang.groupHoursBy = 'Group hours by';
GO.projects.lang.reports = 'Reports';
GO.projects.lang.maxProjectsReached='The maximum number of projects has been reached. Contact your hosting provider to activate unlimited usage of the projects module.';
GO.projects.lang.summary='Summary';
GO.projects.lang.timeTracking='Time tracking';
/* table: pm_statuses */
GO.projects.lang.status="Status";
GO.projects.lang.statuses="Statuses";
/* table: pm_types */
GO.projects.lang.type="Permission type";
GO.projects.lang.types="Permission types";

GO.projects.lang.customer='Customer';
GO.projects.lang.filter='Filter';

GO.projects.lang.dueAt='Due at';
GO.projects.lang.unitsBudget='Budgetted units';
GO.projects.lang.profit='Profit';
GO.projects.lang.unitsLeft='Units left';

GO.projects.lang.nextMonth='Next month';
GO.projects.lang.previousMonth='Previous month';
GO.projects.lang.importEvents='Import appointments';

GO.projects.lang.specifyFee='Specify fee at each booking';

GO.projects.lang.subprojects='Sub items';
GO.projects.lang.subproject='Sub item';

GO.projects.lang.unitsBooked='Units booked';
GO.projects.lang.budgetReached='The units budget has been reached!';
GO.projects.lang.projectEnded='This project should have been completed already!';

/* table: pm_templates */
GO.projects.lang.template="Project template";
GO.projects.lang.templates="Project templates";

GO.projects.lang.confirmBookedHours='You have booked {HOURS} hours. Are you sure you want to close this week?';
GO.projects.lang.successBookedHours='{HOURS} hours have been booked';
GO.projects.lang.openWeek='Open week';
GO.projects.lang.closeWeek='Close week';
GO.projects.lang.weekOverview='Weekview';
GO.projects.lang.totalBudget='Total budget';
GO.projects.lang.totalDiff='Total remaining';
GO.projects.lang.printMonths='Print months';
GO.projects.lang.printUsers='Print users';
GO.projects.lang.manageWeeks='Manage weeks';
GO.projects.lang.timerRunning='Week can\'t be closed. There is a timer running in this week';
GO.projects.lang.goToWeek='Go to week';
GO.projects.lang.goTo='Go to';
GO.projects.lang.selectWeek='Select week';
GO.projects.lang.contact='Contact';
GO.projects.lang.timer='Timer';
GO.projects.lang.total='<b>Total</b>';
GO.projects.lang.tree='Projects Tree';
/* table: pm_templates_events */
GO.projects.lang.templateEvent="Action";
GO.projects.lang.templateEvents="Actions";
GO.projects.lang.timeOffset="Start after (Days)";
GO.projects.lang.duration="Duration (Hours)";
GO.projects.lang.reminder="Reminder";

GO.projects.lang.projectManager='Manager';

GO.projects.lang.startTime='Start date';

GO.projects.lang.showMineOnly='Show my projects only';


/* table: pm_expenses */
GO.projects.lang.expense="Expense";
GO.projects.lang.expenses="Expenses";
GO.projects.lang.amount="Amount";
GO.projects.lang.income="Income";
/* table: pm_report_templates */
GO.projects.lang.reportTemplate="Report template";
GO.projects.lang.reportTemplates="Report templates";
GO.projects.lang.fields="Fields";

/* table: pm_report_pages */
GO.projects.lang.reportPage="Page";
GO.projects.lang.reportPages="Pages";
GO.projects.lang.title="Title";
GO.projects.lang.subtitle="Subtitle";
GO.projects.lang.content="Content";


/* table: pm_custom_reports */
GO.projects.lang.customReport="Report";
GO.projects.lang.customReports="Reports";
GO.projects.lang.startTime="Start date";
GO.projects.lang.endTime="End date";

GO.projects.lang.selectTemplate='Select template';

GO.projects.lang.bill='Bill';

GO.projects.lang.expenseTypes='Expense types';

GO.projects.lang.invoiceTogether='Invoice the project and subprojects together in one invoice';
GO.projects.lang.invoiceSeparately='Create a separate invoice for each subproject';

GO.projects.lang.billAlreadyBilled='Also bill hours and expenses that already have been billed';

GO.projects.lang.overrideDefaultFees="Use different fees";
GO.projects.lang.incomeTypes='Income types';
GO.projects.lang.fields='Fields';

GO.projects.lang.emailProjectManagers='E-mail to projectmanagers';
GO.projects.lang.confirmEmailProjectManagers='Are you sure you want to send each single report in a batch to the project manager?';


GO.projects.lang.batchReportSingle='Create report for this project';
GO.projects.lang.batchReportSubprojects='Create report for each direct subproject';
GO.projects.lang.batchReportQuery='Create report for each subproject that matches the query';

GO.projects.lang.query='Query';

GO.projects.lang.parentProject='Parent project';
GO.projects.lang.standardProjectFields='Standard project fields';

GO.projects.lang.header='Header';
GO.projects.lang.footer='Footer';

GO.projects.lang.backgroundImage='Background image';
GO.projects.lang.customProjectFields='Custom project fields';
GO.projects.lang.customReportFields='Custom report fields';

GO.projects.lang.batchReports='Batch reports';

GO.projects.lang.recipient='Recipient';
GO.projects.lang.payoutTimeregistrationUsers='Payout timeregistration users';

GO.projects.lang.remindForTimeregistration='Remind for timeregistration';
GO.projects.lang.remindForApproval='Remind for approval';
GO.projects.lang.selectPeriod='Select period';
GO.projects.lang.tooltipSpecialFees='Optionally you can define some extra fees here which users can select specifically';
GO.projects.lang.tooltipDefaultFees='Define the default fees of users here';

GO.projects.lang.createNewPermissionsType='Create new permission type';

GO.projects.lang.associations='Associations';
GO.projects.lang.useOwn='Use own';
GO.projects.lang.noAssociation='No association';
GO.projects.lang.useParentProject='Use the associations of the parent project';

GO.projects.lang.hoursAlreadyApproved='The hours have already been approved and may not be edited.';
GO.projects.lang.avoidPageBreaks ="Avoid page breaks in the report";

GO.projects.lang.itemTemplate = "Invoice item template";
GO.projects.lang.totalsReport = 'Totals report';

GO.projects.lang.defaultPermissionType='Default permission type';
GO.projects.lang.defaultStatus='Default status';

GO.projects.lang.availableCustomFields='Available custom fields';
GO.projects.lang.customTabs='Custom tabs';