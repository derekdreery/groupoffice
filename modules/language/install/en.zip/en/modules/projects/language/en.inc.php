<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('projects'));

$lang['projects']['name']='Projects';
$lang['projects']['description']='Project manager with time registration';

$lang['projects']['projects']='Projects';

$lang['link_type'][5]=$lang['projects']['project']='Project';
$lang['projects']['status']='Status';
$lang['projects']['statuses']='Statuses';
$lang['projects']['type']='Type';
$lang['projects']['types']='Types';

$lang['projects']['ongoing']='Ongoing';
$lang['projects']['complete']='Complete';

$lang['projects']['imported_events']='Imported %s events.';
$lang['projects']['ignored_events']='Ignored %s events because an identical booking was already present.';

$lang['projects']['days']='Days';
$lang['projects']['units']='Units';
$lang['projects']['units_budget']='Units budggeted';
$lang['projects']['units_diff']='Units left';
$lang['projects']['ext_fee_value']='External fee';
$lang['projects']['int_fee_value']='Internal fee';
$lang['projects']['profit']='Profit';
$lang['projects']['fee']='Fee';

$lang['projects']['type_not_empty']='There are existing projects with this type. You can\'t delete a type that projects use.';

$lang['projects']['from_project']='From project';
$lang['projects']['overall_totals']='Overall totals';
$lang['projects']['project_totals']='Project totals';
$lang['projects']['template']='Template';

$lang['projects']['template']='Template';
$lang['projects']['templates']='Templates';

$lang['projects']['total_budget']='Total budget';
$lang['projects']['total_diff']='Total remaining';

$lang['projects']['period']='Period';
$lang['projects']['week_closed']='Closed';
$lang['projects']['week_open']='Open';

$lang['projects']['start_timer']='Start timer for this project';
$lang['projects']['stop_timer']='Stop timer for this project';

$lang['projects']['projectExists']='A project with this name already exists';
$lang['projects']['template_event']='Template event';
$lang['projects']['template_events']='Template events';
$lang['projects']['expense']='Expense';
$lang['projects']['expenses']='Expenses';
$lang['projects']['report_template']='Report template';
$lang['projects']['report_templates']='Report templates';
$lang['projects']['report_page']='Report page';
$lang['projects']['report_pages']='Report pages';

$lang['projects']['custom_report']='Custom report';
$lang['projects']['custom_reports']='Custom reports';

$lang['projects']['scheduled_invoice']='The invoice has been scheduled successfully. Change the status of the invoice to send it out.';
$lang['projects']['scheduled_invoices']='%s invoices have been scheduled successfully in the billing module. You can use a batchjob in the billing module to send them all out.';

$lang['projects']['nothing_to_invoice']='No invoices were created because there were no time registrations or expenses found in the given period.';

$lang['projects']['noProjectManager']='Could not find a project manager for %s';
$lang['projects']['reportAttached']='In the PDF attachment you\'ll find the report %s';
$lang['projects']['allReportsSent']='All reports were sent';

$lang['projects']['fee_per_unit']='Fee per unit';

$lang['projects']['bill_item_template'] = '{project_name}: {registering_user_name} (col_XX, col_XY) worked {units} hours on {description} in {days} days';
$lang['projects']['payout_item_template'] = '{project_name}: {description} of {responsible_user_name} (col_YY, col_YZ) in {units} hours over {days} days';