<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('modules'));

	$lang['modules']['name'] = 'Modules';
	$lang['modules']['description'] = 'Admin module; Managing modules.';
	$lang['modules']['deleteModule'] = 'The module "Modules" cannot be deleted!';
?>