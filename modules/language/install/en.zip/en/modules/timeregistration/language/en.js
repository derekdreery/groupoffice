/**
 * Don't copy the next lines into a translation
 */

Ext.namespace('GO.projects');
Ext.namespace('GO.timeregistration');

GO.timeregistration.lang={};
/**
 * Copy everything below for translations
 */

GO.timeregistration.lang.timeregistrationMode='Timeregistration mode';
GO.timeregistration.lang.gridMode='A grid with all projects for a single entry per project per day. Entering data is simple.';
GO.timeregistration.lang.multipleMode='Multiple timeregistrations per project per day possible. Entering data is more complex.';
GO.timeregistration.lang.roundMinutes='Round time input to every';
GO.timeregistration.lang.noRound = 'no rounding';
GO.timeregistration.lang.minutes = 'minutes';


GO.timeregistration.lang.showTimeregistrationFees='Show fees in time tracking screen';
GO.timeregistration.lang.roundUp='Always round up';