<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('timeregistration'));

$lang['timeregistration']['name']='Timeregistration';
$lang['timeregistration']['description']='Timeregistration module for projects';

$lang['timeregistration']['approvalRequiredSubject']='Approval required';
$lang['timeregistration']['approvalRequiredBody']='%s has made a timeregistration. The timeregistration can be approved at %s';

