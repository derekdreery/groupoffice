<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('formprocessor'));
$lang['formprocessor']['name']='Formprocessor';
$lang['formprocessor']['description']='Can be used to create contact forms, newsletter subscriptions and adding contacts from a website';
