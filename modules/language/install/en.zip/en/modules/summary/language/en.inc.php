<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('summary'));

$lang['summary']['name']='Startpage';
$lang['summary']['description']='Show an overview of different actual items';

$lang['summary']['default_rss_url']='http://newsrss.bbc.co.uk/rss/newsonline_world_edition/front_page/rss.xml';
$lang['summary']['default_rss_title']='News';
$lang['summary']['announcement']='Announcement';
$lang['summary']['announcements']='Announcements';
