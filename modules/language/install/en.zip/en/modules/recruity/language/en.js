Ext.namespace('GO.recruity');

GO.moduleManager.on('languageLoaded',function(){
	if(GO.projects){
		GO.projects.lang.project = 'Vacature';
		GO.projects.lang.projects = 'Vacatures';
		GO.projects.lang.noProjects = 'Geen vacatures gevonden';
		GO.projects.lang.projectInfo = 'Vacature informatie';
		GO.projects.lang.activeProjects = 'Actieve vacatures';		
	}
});