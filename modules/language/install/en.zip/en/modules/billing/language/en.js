
/**
 * Don't copy the next line into a translation
 */
Ext.namespace('GO.billing');
GO.billing.lang={};
GO.billing.lang.billing='Billing';
/**
 * Copy everything below for translations
 */


/* table: bs_books */
GO.billing.lang.book="Book";
GO.billing.lang.books="Books";
GO.billing.lang.paymentTermin="Payment term";
GO.billing.lang.orderIdPrefix="Order prefix";
GO.billing.lang.template="Template";
GO.billing.lang.nextId="Next id";
GO.billing.lang.defaultVat="Tax";
GO.billing.lang.currency="Currency";
GO.billing.lang.orderCsvTemplate="Order CSV template";
GO.billing.lang.itemCsvTemplate="Item CSV template";
GO.billing.lang.countryId="Country";
GO.billing.lang.bcc="Bcc";

/* table: bs_orders */
GO.billing.lang.order="Order";
GO.billing.lang.orders="Orders";
GO.billing.lang.statusId="Status";
GO.billing.lang.bookId="Book";
GO.billing.lang.languageId="Language";
GO.billing.lang.orderId="Order";
GO.billing.lang.poId="Purchase order";
GO.billing.lang.companyId="Company";
GO.billing.lang.contactId="Contact";
GO.billing.lang.btime="Date";
GO.billing.lang.ptime="Paid at";
GO.billing.lang.costs="Costs";
GO.billing.lang.subtotal="Subtotal";
GO.billing.lang.vat="VAT";
GO.billing.lang.total="Total";
GO.billing.lang.customer="Customer";
GO.billing.lang.customerContact="Contact";
GO.billing.lang.customerVatNo="VAT no.";
GO.billing.lang.recurType="Recur";
GO.billing.lang.paymentMethod="Payment method";
GO.billing.lang.recurredOrderId="Recurred order";
GO.billing.lang.reference="Reference";
GO.billing.lang.orderBonusPoints="Order bonus points";

/* table: bs_expense_books */
GO.billing.lang.expenseBook="Expense book";
GO.billing.lang.expenseBooks="Expense books";
GO.billing.lang.currency="Currency";

/* table: bs_expenses */
GO.billing.lang.expense="Expense";
GO.billing.lang.expenses="Expenses";
GO.billing.lang.categoryId="Category";
GO.billing.lang.invoiceNo="Invoice no.";
GO.billing.lang.btime="Date";
GO.billing.lang.subtotal="Subtotal";
GO.billing.lang.vatPercentage="VAT percentage";
GO.billing.lang.paid="Paid";

/* table: bs_order_statuses */
GO.billing.lang.orderStatus="Order status";
GO.billing.lang.orderStatuses="Order statuses";
GO.billing.lang.maxAge="Max order age";
GO.billing.lang.paymentRequired="Payment required";
GO.billing.lang.removeFromStock="Remove from stock";

/* table: bs_order_status_history */
GO.billing.lang.orderStatusHistory="Order status history";
GO.billing.lang.orderId="Order";
GO.billing.lang.statusId="Status";
GO.billing.lang.notified="Notified";
GO.billing.lang.notificationEmail="Notification email";
GO.billing.lang.comments="Comments";

/* table: bs_products */
GO.billing.lang.product="Product";
GO.billing.lang.products="Products";
GO.billing.lang.sortOrder="Sort order";
GO.billing.lang.image="Image";
GO.billing.lang.costPrice="Cost price";
GO.billing.lang.listPrice="List price";
GO.billing.lang.totalPrice="Total price";
GO.billing.lang.supplier="Supplier ";
GO.billing.lang.supplierProductId="Supplier product";
GO.billing.lang.allowBonusPoints="Allow bonus points";
GO.billing.lang.special="Special";
GO.billing.lang.specialListPrice="Special list price";
GO.billing.lang.specialTotalPrice="Special total price";
GO.billing.lang.chargeShippingCosts="Charge shipping costs";
GO.billing.lang.stock="Stock";
GO.billing.lang.bonusPoints="Bonus points";
GO.billing.lang.requiredProducts="Required products";

/* table: bs_batchjobs */
GO.billing.lang.batchjob="Batchjob";
GO.billing.lang.batchjobs="Batchjobs";
GO.billing.lang.time="Time";
GO.billing.lang.fromStatusId="From status";
GO.billing.lang.toStatusId="To status";

/* table: bs_batchjob_orders */
GO.billing.lang.batchjobOrder="Batchjob order";
GO.billing.lang.batchjobOrders="Batchjob orders";
GO.billing.lang.batchjobId="Batchjob";
GO.billing.lang.orderId="Order ID";

/* table: bs_templates */
GO.billing.lang.template="Template";
GO.billing.lang.templates="Templates";
GO.billing.lang.title="Title";
GO.billing.lang.from="From";
GO.billing.lang.to="To";
GO.billing.lang.marginTop="Margin top";
GO.billing.lang.marginBottom="Margin bottom";
GO.billing.lang.marginLeft="Margin left";
GO.billing.lang.marginRight="Margin right";
GO.billing.lang.pageFormat="Page format";
GO.billing.lang.fromWidth="From width";
GO.billing.lang.start="Start";
GO.billing.lang.footer="Footer";
GO.billing.lang.closing="Closing";
GO.billing.lang.numberName="Number name";
GO.billing.lang.referenceName="Reference name";
GO.billing.lang.dateName="Date name";
GO.billing.lang.logo="Logo";
GO.billing.lang.logoWidth="Logo width";
GO.billing.lang.logoHeight="Logo height";
GO.billing.lang.logoPosition="Logo position";
GO.billing.lang.showSupplierProductId="Show supplier product ID";
GO.billing.lang.showAmounts="Show amounts";
GO.billing.lang.showUnitPrices="Show unit prices";
GO.billing.lang.showTax='Show tax per line';
GO.billing.lang.showProdPrices="Show prod prices";
GO.billing.lang.showTotalPrices="Show total prices";
GO.billing.lang.addressMarginTop="Address margin top";
GO.billing.lang.addressMarginBottom="Address margin bottom";
GO.billing.lang.addressMarginLeft="Address margin left";


/* table: bs_items */
GO.billing.lang.item="Item";
GO.billing.lang.items="Items";
GO.billing.lang.productId="Product";
GO.billing.lang.unitCost="Unit cost";
GO.billing.lang.unitPrice="Unit price";
GO.billing.lang.unitList="Unit list";
GO.billing.lang.unitTotal="Unit total";
GO.billing.lang.amount="Amount";
GO.billing.lang.discount="Discount";
GO.billing.lang.sortOrder="Sort order";

/* table: bs_expense_categories */
GO.billing.lang.expenseCategory="Expense category";
GO.billing.lang.expenseCategories="Expense categories";
GO.billing.lang.expenseBookId="Expense book";

/* table: bs_languages */
GO.billing.lang.language="Language";
GO.billing.lang.languages="Languages";

GO.billing.lang.invoice="Invoice";
GO.billing.lang.invoiceDate="Invoice date";


GO.billing.lang.defaultSalutation='Dear sir/madam';

GO.billing.lang.margin='Margin';
GO.billing.lang.profit='Profit';
GO.billing.lang.product="Product";

GO.billing.lang.notifyCustomer="Notify customer";

GO.billing.lang.recurTypes={};
GO.billing.lang.recurTypes['1M'] ="1 "+GO.lang.strMonth;
GO.billing.lang.recurTypes['2M'] ="2 "+GO.lang.strMonths;
GO.billing.lang.recurTypes['3M'] ="3 "+GO.lang.strMonths;
GO.billing.lang.recurTypes['4M'] ="4 "+GO.lang.strMonths;
GO.billing.lang.recurTypes['6M'] ="6 "+GO.lang.strMonths;
GO.billing.lang.recurTypes['1Y'] ="1 "+GO.lang.strYear;
GO.billing.lang.recurTypes['2Y'] ="2 "+GO.lang.strYears;
GO.billing.lang.recurTypes['3Y'] ="3 "+GO.lang.strYears;


GO.billing.lang.catalog='Catalog';
GO.billing.lang.report='Report';
GO.billing.lang.productCatalog='Product catalog';
GO.billing.lang.productCatalogSearch='Product catalog search';
GO.billing.lang.changeOrderStatus='Change orders from status';
GO.billing.lang.toStatus='To status';
GO.billing.lang.selectStatus='Select a status...';
GO.billing.lang.changingStatuses='Changing statuses';
GO.billing.lang.startCompleted='0% completed';
GO.billing.lang.completed='completed';
GO.billing.lang.startPeriod='Start period';
GO.billing.lang.endPeriod='End period';
GO.billing.lang.ordersSuccessChanged=' orders were successfully changed.';
GO.billing.lang.ordersFailed='The following orders failed:';
GO.billing.lang.finished='Finished';
GO.billing.lang.totalOrders='Total orders';
GO.billing.lang.noEmailModule='E-mail module is not installed.';
GO.billing.lang.categories='Categories';
GO.billing.lang.addProduct='Add product';
GO.billing.lang.addCategory='Add category';
GO.billing.lang.newFolder='New folder';
GO.billing.lang.turnOver='Turnover in';
GO.billing.lang.abroad='Abroad';
GO.billing.lang.intracommunity='Intracommunity';
GO.billing.lang.EUCustomers='EU Customers';
GO.billing.lang.category='Category';
GO.billing.lang.changeOrderStatus='Change status of current order';
GO.billing.lang.noChangeStatus='Don\'t change the status';
GO.billing.lang.copyToBook='Copy to book';
GO.billing.lang.duplicateOrder='Duplicate order';
GO.billing.lang.information='Information';
GO.billing.lang.exportOrders='Export orders';
GO.billing.lang.restartRequiredTitle='Restart required';
GO.billing.lang.restartRequired='"A restart is required for changes to take effect. Logout and log back in.';
GO.billing.lang.filter='Filter';
GO.billing.lang.duplicate='Duplicate';
GO.billing.lang.informationAbout='Information about';
GO.billing.lang.showScheduledOrders='Show scheduled orders';
GO.billing.lang.sceduledOrder='Scheduled order';
GO.billing.lang.PDFTemplate='PDF template';
GO.billing.lang.noGeneratePDF='Don\'t generate a PDF';
GO.billing.lang.emailTemplate='E-mail template';
GO.billing.lang.deleteImage='Delete image';
GO.billing.lang.deleteLogo='Delete logo';
GO.billing.lang.period='Period';
GO.billing.lang.turnover='Turnover';
GO.billing.lang.expenses='Expenses';
GO.billing.lang.exampleAddress='Example company\nSome street 123\n1234 AB Some city';
GO.billing.lang.pageSettings='Page settings';

GO.billing.lang.selectStatus='Select an order status';
GO.billing.lang.shortDescription='Short description';
GO.billing.lang.editCategory='Edit category';
GO.billing.lang.webshopId="Webshop"; 

GO.billing.lang.total='Total';
GO.billing.lang.moneyAmount = 'Amount';

GO.billing.lang.updateOrderDate='Update order date to current date';
GO.billing.lang.updateProducts='Update products in order from catalog';

GO.billing.lang.leftCol='Left column';
GO.billing.lang.rightCol='Right column';
GO.billing.lang.rightColCoordinates='Right column coordinates';
GO.billing.lang.leftColCoordinates='Left column coordinates';
GO.billing.lang.top='Top';
GO.billing.lang.left='Left';

GO.billing.lang.frontpage='Frontpage';
GO.billing.lang.pagebreak='Continue to the next page after the frontpage';

GO.billing.lang.callAfterDays = 'Call after days';

GO.billing.lang.emailBuyers='E-mail buyers';

GO.billing.lang.logoText='The logo can also be a full page background image. Leave the width and height at zero to make it stretch to the full page size. Look at the page settings to see the page measurements. For the best print results, it is recommended that you use an image that is twice the size that you will set here.';

GO.billing.lang.customerExtra='Extra';

GO.billing.lang.demoMode='Demo mode';
GO.billing.lang.demoText='The billing module is running in demo mode. You can create a maximum of %max_orders% orders';
GO.billing.lang.yearReport='Year report';
GO.billing.lang.customerReport='Customer report';

GO.billing.lang.readOnly='Make order read only';
GO.billing.lang.changeStatus='Change status';

GO.billing.lang.selectFiles = 'Please select a product or category in the right panel first.';
GO.billing.lang.selectDestination = 'Select a target category first.';

GO.billing.lang.addPageBreak='Add page break';
GO.billing.lang.notifyCustomer='Notify customer?';
GO.billing.lang.notifyCustomerText='Do you want to send an e-mail to the customer about this status change?';
GO.billing.lang.selectBook='Select a book please...';

GO.billing.lang.costCode = 'Cost code';
GO.billing.lang.costCodes = 'Cost codes';
GO.billing.lang.newCostCode = 'New cost code';