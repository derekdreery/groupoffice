<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('billing'));
$lang['billing']['name']='Billing';
$lang['billing']['description']='A module to create quotes, orders and invoices.';

$lang['billing']['dontDeleteDefaultLang']="You can't delete the default language.";

$lang['billing']['book']='Book';
$lang['billing']['books']='Books';
$lang['link_type'][7]=$lang['billing']['order']='Order';
$lang['billing']['orders']='Orders';
$lang['billing']['expense_book']='Expense book';
$lang['billing']['expense_books']='Expense books';
$lang['billing']['expense']='Expense';
$lang['billing']['expenses']='Expenses';
$lang['billing']['order_status']='Order status';
$lang['billing']['order_statuses']='Order statuses';
$lang['billing']['order_status_history']='Order status history';
$lang['billing']['order_status_history']='Order status history';
$lang['billing']['product']='Product';
$lang['billing']['products']='Products';
$lang['billing']['batchjob']='Batchjob';
$lang['billing']['batchjobs']='Batchjobs';
$lang['billing']['batchjob_order']='Batchjob order';
$lang['billing']['batchjob_orders']='Batchjob orders';
$lang['billing']['template']='Template';
$lang['billing']['templates']='Templates';
$lang['billing']['item']='Item';
$lang['billing']['items']='Items';
$lang['billing']['expense_category']='Expense category';
$lang['billing']['expense_categories']='Expense categories';
$lang['billing']['language']='Language';
$lang['billing']['languages']='Languages';

/* for pdf */
$lang['billing']['amount']= 'Amount';
$lang['billing']['unit_price']= 'Unit price<br />excl.';
$lang['billing']['unit_total']= 'Unit price<br />incl.';
$lang['billing']['unit_cost']= 'Unit cost';
$lang['billing']['unit_list']= 'Catalog<br />price';
$lang['billing']['vat']= 'Tax';
$lang['billing']['terms']= 'Terms';
$lang['billing']['invoice_title']= 'INVOICE';
$lang['billing']['invoice_number']= 'Invoice no.';
$lang['billing']['subtotal']= 'Sub-total';
$lang['billing']['total']= 'Total';
$lang['billing']['date_sent']= 'Date sent';

$lang['billing']['quote_number']= 'Quote number';
$lang['billing']['order_number']= 'Order number';

$lang['billing']['quote_date']= 'Quote date';
$lang['billing']['order_date']= 'Order date';

$lang['billing']['invoices']= 'Invoices';
$lang['billing']['quotes']= 'Quotes';

$lang['billing']['waiting_for_payment']='Waiting for payment';
$lang['billing']['reminded']='Reminder sent';
$lang['billing']['processing_payment']='Processing payment';
$lang['billing']['paid']='Paid';
$lang['billing']['credit']='Credit';

$lang['billing']['sent']= 'Sent';
$lang['billing']['accepted']='Accepted';
$lang['billing']['lost']='Lost';

$lang['billing']['in_process']='In process';
$lang['billing']['delivered']='Delivered';
$lang['billing']['billed']='Billed';

$lang['billing']['quote']='Quote';
$lang['billing']['invoice']='Invoice';
$lang['billing']['order']='Order';

$lang['billing']['office_supplies']='Office supplies';
$lang['billing']['cars']='Cars';
$lang['billing']['internet']='Internet';
$lang['billing']['other']='Other';

$lang['billing']['reference']='Reference';


$lang['billing']['status_email_template']='
%customer_salutation%,<br />
<br />
Your %type% is in status %status%.<br />
<br />
With kind regards,<br />
<br />
Some company
';

$lang['billing']['invoice_unit_price']= 'Unit price';
$lang['billing']['item_description']='Description';
$lang['billing']['invoice_date']= 'Invoice date';
$lang['billing']['status_email_subject']= 'Your %type% has status %status%';

$lang['billing']['to_the_attention']='attn.';

$lang['billing']['none']='None';
$lang['billing']['default']='Default';

$lang['billing']['export']='Export';
$lang['billing']['supplier_prod_no']='Product number';
$lang['billing']['discount']='Discount';
$lang['billing']['invalid_status']='Invalid status. Maybe you\'ve added a language and didn\'t update the statuses?';
$lang['billing']['no_email_template']='No e-mail template defined!';
$lang['billing']['invald_email']='Invalid e-mail address';
$lang['billing']['no_orders']='There are no orders to process';
$lang['billing']['no_logo_size']='Could not determine the size of your logo. Please enter it manually.';

$lang['billing']['max_orders_reached']='The maximum number of orders has been reached. Contact your hosting provider about unlimited usage of the billing module.';

$lang['billing']['scheduled']='Scheduled';
$lang['billing']['quarter_total']='Quarter total';
$lang['billing']['year_total']='Year total';

$lang['billing']['cant_move_into_itself']='Can not move into itself';