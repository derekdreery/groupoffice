Ext.namespace('GO.bookmarks');

GO.bookmarks.lang={};

GO.bookmarks.lang.bookmarks='Bookmarks';
GO.bookmarks.lang.bookmark='Bookmark';

GO.bookmarks.lang.category='Category';
GO.bookmarks.lang.title='Title';
GO.bookmarks.lang.description='Description';
GO.bookmarks.lang.logo='Logo';
GO.bookmarks.lang.extern='Open in new browser tab';
GO.bookmarks.lang.administrateCategories='Administrate categories';
GO.bookmarks.lang.thumbnails='Thumbnails';
GO.bookmarks.lang.chooseIcon='Choose icon for bookmark';
GO.bookmarks.lang.clearLogo='Clear Logo';
GO.bookmarks.lang.uploadLogo='Upload Logo';
GO.bookmarks.lang.showAll='Show all';
GO.bookmarks.lang.sharedCategory='Shared category';