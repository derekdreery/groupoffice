<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('bookmarks'));
$lang['bookmarks']['name']='Bookmarks';
$lang['bookmarks']['description']='A module to create bookmarks.';

$lang['bookmarks']['general']='General';
$lang['bookmarks']['googleDescription']="Search the web";