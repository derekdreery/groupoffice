<?php
//Uncomment this line in new translations!
//require($GO_LANGUAGE->get_fallback_language_file('groups'));
$lang['groups']['name'] = 'Groups';
$lang['groups']['description'] = 'Admin module; Managing user groups.';
$lang['groups']['noDeleteAdmins'] = 'You can\'t delete the group Admins';
$lang['groups']['noDeleteEveryone'] = 'You can\'t delete the group Everyone';
$lang['groups']['groupNameAlreadyExists'] = 'The group you are trying to create already exists';
$lang['groups']['dontRemoveAdmin']='You can\'t remove the primary administrator from the administrator group';
?>